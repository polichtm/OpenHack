﻿CREATE TABLE [dbo].[Numbers] (
    [Number] INT NOT NULL
)

